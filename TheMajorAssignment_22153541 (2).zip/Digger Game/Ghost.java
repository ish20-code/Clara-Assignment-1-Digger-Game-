/**
 * Ghost Class
 * 
 * Available methods (see Assignment document for explanations on what each method does):
 * earthAbove, earthBelow, earthToLeft, earthToRight,
 * earthFront, goldFront
 * getDirection, setDirection,
 * move(speed),
 * animate, animateDead,
 * intersects(Character), intersectsWithName(String)
 * getClara, getGhostHealer,
 * isAboveMe(Character), isBelowMe(Character), isToMyLeft(Character), isToMyRight(Character),
 * makeClaraDead,
 * playGhostEatenSound,
 * wrapAroundWorld
 */
class Ghost extends Character
{
    // use this name for checking intersections with gold sacks
    public static final String  GOLD_TILE_NAME = "Gold";
    public final String  UP = "up";    
    public final String  DOWN = "down";    
    public final String  LEFT = "left";    
    public final String  RIGHT = "right";
    boolean intersection = false;
    BoardTile clara = getClara();
    int randomNumber = 0;
    

    //Add and initialise Ghost variables here
    
    /**
     * Act method, runs every frame
     */
public void act() {
    
    if (intersectsWithName(GOLD_TILE_NAME)){
        animate();
        animateDead();
    }
    else {int speed = 7;
     // Move towards Clara's position
    if (intersection && randomNumber != 5){
        if (isAboveMe(clara) && !earthAbove()) {
            setDirection(UP);
        } else if (isBelowMe(clara) && !earthBelow()) {
            setDirection(DOWN);
        } else if (isToMyRight(clara) && !earthToRight()) {
            setDirection(RIGHT);
        } else if (isToMyLeft(clara) && !earthToLeft()) {
            setDirection(LEFT);
        }
    }
   

    // Move if no earth in front, else adjust direction
     if (earthFront()) {
        // If blocked, try alternate directions
        String direction = getDirection();
        if (direction == UP || direction == DOWN) {
                setDirection(LEFT);
                if (earthFront()) {
                    setDirection(RIGHT);
                }

        } else {
            setDirection(DOWN);
            if (earthFront()) {
                setDirection(UP);
            }
        }
    }
    else {
        move(speed);
    }
    

    // Check for collision with Clara and handle it
    if (intersects(clara)) {
        makeClaraDead();
    }

    // Check for intersection with an object named "Gold"
    if (intersectsWithName(GOLD_TILE_NAME)) {
        animateDead();
    }

    // Handle intersections with earth surroundings
    
    if ((earthToRight() && !earthAbove() && !earthBelow() && !earthToLeft()) ||
        (earthAbove() && !earthToRight() && !earthBelow() && !earthToLeft()) ||
        (earthToLeft() && !earthAbove() && !earthBelow() && !earthToRight()) ||
        (earthBelow() && !earthAbove() && !earthToRight() && !earthToLeft())) {
        intersection = true;
        randomNumber = (int)(Math.random() * 10);
    }
    else{
    intersection = false;
    }}
}
    { 
        if (isAboveMe(getGhostHealer()) && !earthAbove()) {
            setDirection(UP);
        } else if (isBelowMe(getGhostHealer()) && !earthBelow()) {
            setDirection(DOWN);
        } else if (isToMyRight(getGhostHealer()) && !earthToRight()) {
            setDirection(RIGHT);
        } else if (isToMyLeft(getGhostHealer()) && !earthToLeft()) {
            setDirection(LEFT);
        }  
    }
}    

