/**
 * Gold
 * 
 * Available methods (see Assignment document for explanations on what each method does):
 * getDirection, setDirection,
 * move(speed),
 * intersects(Character)
 * animate, animateFlip, animateShake 
 * playBombTicking, playGoldFall, playGoldDrop, 
 * removeSelf, putBrokenGold
 **/
class Gold extends Character {
    
    int frameCounter = 0;
    int secondCounter = 0;

    boolean isFalling = false;
    public void act() {
        wrapAroundWorld();
        // Program behaviour of gold sacks here
        frameCounter++;
        if (frameCounter % 20 == 0) {
            secondCounter++;
        }

        if (!earthBelow()){
            // BEFORE 3 SECONDS
            if (!earthBelow()){
            if (secondCounter < 3){
                    animateShake();
                }
            }

            // AFTER 3 SECONDS
            if (secondCounter >= 3){
            isFalling = true;}
        if (isFalling) {
            setDirection("down");
             if (frameCounter % 5 == 0){
                animate();
            }
            if (frameCounter % 10 == 0){
                animateFlip();
                playGoldFall();
                playGoldDrop();
            }
            move(6);
        }
        if (earthBelow()){
            removeSelf();
            putBrokenGold();
        }
        if (isAtBottom()){
            stopAtBottomEdge();
            removeSelf();
            putBrokenGold();
        }
    }
    }
}