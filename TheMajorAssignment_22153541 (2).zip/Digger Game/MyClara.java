/**
 * MyClara
 * 
 * Available methods (see Assignment document for explanations on what each method does):
 * getDirection, setDirection,
 * move,
 * animate, animateDead, 
 * onLeaf, removeLeaf, 
 * onEarth, removeEarth
 * onGold, removeGold
 * allLeavesEaten, allGoldEaten
 * isClaraDead,
 * playLeafEatenSound, playCollectGold
 * playIntro, isIntroStillPlaying,
 * wrapAroundWorld,
 * getCurrentLevelNumber, advanceToLevel
 */
class MyClara extends Clara
{
    // Please leave this first level here,
    // until after you've completed Part 13 - "Making and Adding Levels"   
    public final char[][] LEVEL_1 = {
    {'~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~'},
    {'~','%','~','~','~','~','G','~','~','~','~','~',' ',' ',' ',' ',' ','%','?'}, 
    {'~',' ','~','~','~','.','.','~','~','.','G','~',' ','~','~','~','~','~','~'},
    {'~',' ','~','G','~','.','.','~','~','.','~','~',' ','~','~','~','~','~','~'},
    {'~',' ','~','~','~','.','.','G','~','.','~','~',' ','~','~','.','.','.','~'},
    {'~',' ','~','~','~','.',' ','~','~','.','G','~',' ','~','~','.','.','.','~'},
    {'~',' ','~','~','~','~','~','~','~','~','~','~',' ','~','~','.','.','.','~'},
    {'~',' ',' ',' ',' ',' ','~','~','~','~','~','~',' ','~','~','~','~','~','~'},
    {'~','~','~','~','~',' ','~','~','~','~','~','.','.','~','~','~','~','.','~'},
    {'~','.','.','~','~',' ',' ','@',' ',' ',' ',' ',' ','~','~','~','.','.','~'},
    {'~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~'}
    };

    public final char[][] LEVEL_2 = {
    {'~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~'},
    {'~','%','~','~','~','~','%','~','~','~','~','~','%',' ',' ',' ',' ','%','?'}, 
    {'~',' ','~','~','~','.','.','~','~','.','G','~',' ','~','~','~','~','~','~'},
    {'~',' ','~','G','~','.','.','~','~','.','~','~',' ','~','~','~','~','~','~'},
    {'~',' ','~','~','~','.','.',' ','~','.','~','~',' ','~','~','.','.','.','~'},
    {'~',' ','~','~','~','.',' ','~','~','.','G','~',' ','~','~','.','.','.','~'},
    {'~',' ','~','~','~','~','~','~','~','~','~','~','%','~','~','.','.','.','~'},
    {'~',' ',' ',' ',' ',' ','~','~','~','~','~','~',' ','~','~','~','~','~','~'},
    {'~','~','~','~','~',' ','~','~','~','~','~','.','.','~','~','~','~','.','~'},
    {'~','.','.','~','~',' ','G','@',' ','G','G',' ',' ','~','~','~','.','.','~'},
    {'~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~'}
    };




    // Orientation constants
    public final String  UP = "up";    
    public final String  DOWN = "down";    
    public final String  LEFT = "left";    
    public final String  RIGHT = "right";     
    
    // Add and initialise Clara's variables here
    int a = 0;
    int frames = 0;
    
    /**
     * Act method
     * 
     * Runs of every frame
     */ 
    public void act() 
    {   
        frames += 1;
        wrapAroundWorld();
        //Make Clara do things here
        if (Keyboard.isKeyDown(LEFT)){
            setDirection(LEFT);
            move();
        }
        if (Keyboard.isKeyDown(RIGHT)){
            setDirection(RIGHT);
            move();
        }
         if (Keyboard.isKeyDown(UP)){
            setDirection(UP);
            move();
        }
        if (Keyboard.isKeyDown(DOWN)){
            setDirection(DOWN);
            move();
        }
        if (onEarth()){
            removeEarth();
        }
        if (onLeaf()){
            removeLeaf();
            playLeafEatenSound();
        }
        if (onGold()){
            removeGold();
            playCollectGold();
        }
        if (isClaraDead()){
            animateDead();
            if (frames % 5 == 0);
            animate();
        }
        if (frames % 5 == 0){
            animate();
        }
        if (allGoldEaten() && allLeavesEaten()){
            advanceToLevel(LEVEL_2);
        }
    }
}